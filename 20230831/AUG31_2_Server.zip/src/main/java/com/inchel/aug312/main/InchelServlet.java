package com.inchel.aug312.main;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InchelServlet
 */
@WebServlet("/InchelServlet")
public class InchelServlet extends HttpServlet {
	
	//기본생성자와 버전표시값을 필요없으므로 삭제해버렸음.
	//doGet과 doPost만 남은 상태.
	
	//가장 기본적인 요청 형태는 GET 방식이며, GET으로 요청받을 시 doGET을 실행한다.
	//우리는 도메인의 주소를 알고있다면, 직접 주소를 타이핑해서 접속이 가능하다(GET 방식).
	//get 방식은 도메인에 해당 정보가 그대로 노출된다.
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//랜선에 붙어있는 응답용 빨대가 하나 필요하다.(PrintWriter)
		//우리가 서블릿에 뭘 요청하면, 그 값을 받아온 빨대를 하나 생성한다.
		//클라이언트한테, 서버 쪽이 어떤 인코딩을 쓰고 있는지 항상!! 알려줘야 한다.
		response.setCharacterEncoding("UTF-8"); // 클라이언트에게 UTF-8이라고 알려준다.
		PrintWriter out = response.getWriter();
		
		//요청할 때, ?변수명=값&변수명=값&..... 순으로 요청한다.
		//우리가 요청할 때 쓰는 파라미터가, lang이라는 이름으로 language 객체에 들어간다.
		//정확히, 객체에 들어가는 값은 =이후의 값.
		String language = request.getParameter("lang");
		System.out.println(language);
		
		//그리고 아래의 html 코드를 타이핑해본다.
//		out.print("<html>");
//		out.print("<head><title><Hello!></title><meta charset = 'UTF-8'></head>");
//		out.print("<body>");
//		//HTML에 자바 문법도 적용해보기.
//		for(int i = 0; i < 5; i++) {
//		out.print("<marquee>Hello !</marquee>");
//		}
//		out.print("</body>");
//		out.print("</html>");
		
		// 실행했을 때, 주소창 요청 파라미터인 lang의 값에 따라
		// korean이라고 입력하면 '네' 라고 출력
		// english라고 입력하면 'Yes'
		// 그 외에는 '몰라' 라고 출력해보자.
		// <h1>을 이용?
		
		out.print("<html>");
		//아래 코드의 html문 쓸때, meta charset='UTF-8' 요 부분에 띄어쓰기 없게 하자. 띄어쓰면 적용안되는듯.
		out.print("<head><title><Hello!></title><meta charset='UTF-8'></head>");
		out.print("<body>");
		
		if(language.equals("korean")) {
			out.print("<h1>네</h1>");
			out.print("네");
		} else if(language.equals("english")) {
			out.print("<h1>Yes</h1>");
			out.print("Yes");
		} else {
			out.print("<h1>몰라</h1>");
			out.print("몰라");
		}
		
		out.print("</body>");
		out.print("</html>");
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	// POST 형식으로 요청받을 경우 doPost를 실행한다.
	// 이건 우리가 쓰는 일반적인 방법이 아니고, 프로그램을 통해서만 가능하다.
	// 예시) 계정의 비밀번호같이, 주소값에서는 숨겨서 보내고 싶은 것이 있을때 사용한다.
	// POST방식은 데이터를 URL이 아닌, BODY에 붙여서 보낸다고 한다.
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

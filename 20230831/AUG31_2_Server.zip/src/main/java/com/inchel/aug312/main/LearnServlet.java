package com.inchel.aug312.main;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LearnServlet
 */


//아래 코드처럼, @XXXX~~라고 적혀있는 것을 Annotation이라고 한다.
//원래 아래 코드를 전부 구현했어야 했지만, Annotation이 자동으로 처리해준다.
@WebServlet("/LearnServlet") // "" 안에 들어가는 이름은 서블릿 클래스 명과 같아야 한다.
							 // 이 이름의 서블릿을 tomcat에 등록하겠다는 뜻이다. 지울 시 실행 안되므로 주의!
public class LearnServlet extends HttpServlet {
	// HttpServlet 클래스의 기능을 상속받은 LearnServlet을 선언. (뭔가를 요청하면 응답해준다)
	// 여기에 이것저것 추가한다.
	
	//현재 작업의 버전을 표시해주는 값. 지워도 무방하다.
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
	
	//기본생성자가 그냥 만들어져 있음. 이 클래스의 객체는 tomcat이 생성하므로, 별로 쓸일이 없어 지워도 무방하다.
	// event-driven-programming(이벤트 기반 프로그래밍)에 대하여.
	// tomcat이 실행 중일 때 LearnServlet을 실행한다.
	// 그리고 LearnServlet 객체를 만들어서 무한루프를 돌리기 시작한다.
	// 무한루프 동안, 어떠한 이벤트가 발생하면 그것을 처리 후 루프로 복귀한다.
	
	public LearnServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	//여기부터가 핵심.
	//루프를 돌다가, 클라이언트가 이 Servlet에 Get 혹은 Post 방식으로 요청을 한다.
	//그 중 get 방식 요청이 클라이언트에서 오면, 아래 doGet를 실행한다.
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	//루프를 돌다가, 클라이언트가 이 Servlet에 Get 혹은 Post 방식으로 요청을 한다.
	//그 중  방식 요청이 클라이언트에서 오면, 아래 doGet를 실행한다.
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

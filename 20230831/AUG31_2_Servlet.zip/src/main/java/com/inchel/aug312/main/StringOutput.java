package com.inchel.aug312.main;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/StringOutput")
public class StringOutput extends HttpServlet {
	
	//사용자가 입력한 데이터가 주소에 들어갈 때, 본래 한글은 들어가면 안된다.
	//그래서 한글이 들어갈 때면, URL 인코딩방식을 거쳐 %2B%AC이런느낌으로 바꿔야한다.
	//그걸 위해서, 아까 server.xml에 URIEncoding = "UTF-8"같은걸 추가했었음.
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setCharacterEncoding("UTF-8"); // 클라이언트에게 UTF-8이라고 알려준다.
		PrintWriter out = response.getWriter(); // 받아올 값을 다뤄줄 Writer 하나 받아오기
		String string = request.getParameter("String");
		
		out.print("<html>");
		//아래 코드의 html문 쓸때, meta charset='UTF-8' 요 부분에 띄어쓰기 없게 하자. 띄어쓰면 적용안되는듯.
		out.print("<head><title>문자열 출력</title><meta charset='UTF-8'></head>");
		out.print("<body>");
		
		out.print("<h1>GET방식으로 문자열 출력</h1>");
		out.printf("입력한 문자열 : %s", string);
		
		out.print("</table>");
		out.print("</body>");
		out.print("</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); // 서버에 데이터를 전달할 때, 내가 주는 값을 UTF-8로 인코딩하라고 한다.
		response.setCharacterEncoding("UTF-8"); // 서버에서 데이터를 받아올 때, 그 데이터가 UTF-8이라고 알려준다.
		PrintWriter out = response.getWriter(); // 받아올 값을 다뤄줄 Writer 하나 받아오기
		String string = request.getParameter("String");
		
		out.print("<html>");
		//아래 코드의 html문 쓸때, meta charset='UTF-8' 요 부분에 띄어쓰기 없게 하자. 띄어쓰면 적용안되는듯.
		out.print("<head><title>문자열 출력</title><meta charset='UTF-8'></head>");
		out.print("<body>");
		
		out.print("<h1>POST방식으로 문자열 출력</h1>");
		out.printf("입력한 문자열 : %s", string);
		
		out.print("</table>");
		out.print("</body>");
		out.print("</html>");
	}

}

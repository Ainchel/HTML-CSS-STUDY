package com.inchel.aug312.main;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalculatorServlet
 */
@WebServlet("/Calculator")
public class Calculator extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setCharacterEncoding("UTF-8"); // 클라이언트에게 UTF-8이라고 알려준다.
		PrintWriter out = response.getWriter();
		
		//html의 input 태그에서, name으로 지정한 값과 동일하게 getParameter한 값을 받아온다.(String형)
		int x = Integer.parseInt(request.getParameter("a"));
		//html의 input 태그에서, name으로 지정한 값과 동일하게 getParameter한 값을 받아온다.(String형)
		int y = Integer.parseInt(request.getParameter("b"));
		
		out.print("<html>");
		//아래 코드의 html문 쓸때, meta charset='UTF-8' 요 부분에 띄어쓰기 없게 하자. 띄어쓰면 적용안되는듯.
		out.print("<head><title>사칙연산</title><meta charset='UTF-8'></head>");
		out.print("<body>");
		
		out.print("<h1>사칙연산</h1>");
		out.print("<table border = '1'>");

		out.printf("<tr><td> %d + %d = %d</tr></td>", x, y, x + y);
		out.printf("<tr><td> %d - %d = %d</tr></td>", x, y, x - y);
		out.printf("<tr><td> %d x %d = %d</tr></td>", x, y, x * y);
		out.printf("<tr><td> %d / %d = %.2f</tr></td>", x, y, x / (double)y);
		
		out.print("</table>");
		out.print("</body>");
		out.print("</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
